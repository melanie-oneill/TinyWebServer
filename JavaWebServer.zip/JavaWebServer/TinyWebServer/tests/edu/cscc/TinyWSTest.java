package edu.cscc;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TinyWSTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void main() {
    }

    @Test
    public void listen() {
    }

    @Test
    public void log() {
    }

    @Test
    public void fatalError() {
    }

    @Test
    public void fatalError1() {
    }

    @Test
    public void handleError() {
    }

    @Test
    public void getPort() {
    }

    @Test
    public void getDefaultFolder() {
    }

    @Test
    public void getDefaultPage() {
    }
}